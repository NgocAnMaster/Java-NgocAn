public class InvalidIntegerException extends RuntimeException {
    public InvalidIntegerException(String message) {
        super(message);
    }
}
