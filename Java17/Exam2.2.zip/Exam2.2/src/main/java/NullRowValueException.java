public class NullRowValueException extends RuntimeException {
    public NullRowValueException(String message) {
        super(message);
    }
}
