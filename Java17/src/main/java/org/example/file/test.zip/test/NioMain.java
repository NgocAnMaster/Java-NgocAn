package org.test;

import org.apache.commons.lang3.SerializationUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class NioMain {
    public static void main(String[] args) throws IOException {
//        Student student = new Student("hello", "fpt");
//        Files.write(Paths.get("test.txt"), SerializationUtils.serialize(student));
//
//        byte[] bytes = Files.readAllBytes(Paths.get("test.txt"));
//        Student student1 = SerializationUtils.deserialize(bytes);
//        System.out.println(student1);
    }
}
