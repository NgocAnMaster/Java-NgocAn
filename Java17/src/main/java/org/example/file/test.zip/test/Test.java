package org.test;

import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        String originalFolderPath = "original-folder";
        String destFolderPath = originalFolderPath + "/dest-folder";
        String file1Path = originalFolderPath + "/file1.txt";
        String file2Path = originalFolderPath + "/file2.txt";
        String file3Path = originalFolderPath + "/file3.txt";
        String file4Path = originalFolderPath + "/file4.txt";
        String file5Path = originalFolderPath + "/file5.txt";

//        File originalFolder = new File(originalFolderPath);

        File destFolder = new File(destFolderPath);
        destFolder.mkdir();

        File file1 = new File(file1Path);
        File destFile1 = new File(destFolderPath + "/file1.txt");
        file1.renameTo(destFile1);

        File file2 = new File(file2Path);
        File destFile2 = new File(destFolderPath + "/file2.txt");
        file2.renameTo(destFile2);

        File file5 = new File(file5Path);
        file5.delete();

        for (File file : destFolder.listFiles()) {
            System.out.println(file.getName() + " " +
                    new Date(file.lastModified()) + " " +
                    file.length());
        }


    }
}
