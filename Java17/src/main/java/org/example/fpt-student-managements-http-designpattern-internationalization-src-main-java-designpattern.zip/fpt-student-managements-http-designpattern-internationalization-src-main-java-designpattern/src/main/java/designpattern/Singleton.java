package designpattern;

public class Singleton {
}
