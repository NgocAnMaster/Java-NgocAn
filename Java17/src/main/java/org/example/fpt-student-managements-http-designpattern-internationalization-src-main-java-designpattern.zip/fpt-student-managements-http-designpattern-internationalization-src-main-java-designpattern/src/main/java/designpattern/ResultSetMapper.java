package designpattern;

import java.sql.ResultSet;

public class ResultSetMapper {
//    public static <T> T convert(ResultSet resultSet, Class<T> tClass) {
//
//    }
}
