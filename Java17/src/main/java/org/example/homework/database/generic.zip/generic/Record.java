package generic;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
public abstract class Record {
    private Integer id;
    private ZonedDateTime createdAt;
    private ZonedDateTime updatedAt;

}
