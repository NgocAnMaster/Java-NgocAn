package generic;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Student student = Student.builder()
                .name("khoi")
                .dob(LocalDate.of(2020, 1, 1))
                .build();
        Database<Student> studentDatabase = new Database<>();

        studentDatabase.save(student);

        System.out.println(student);
    }
}
