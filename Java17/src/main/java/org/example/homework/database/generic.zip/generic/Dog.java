package generic;

public class Dog {
}
