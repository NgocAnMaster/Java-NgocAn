package generic;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
public class Database<T extends Record> {
    private List<T> records = new ArrayList<>();

    public Record save(T record) {
        ZonedDateTime now = ZonedDateTime.now();

        if (record.getId() != null) {
            T existing = find(record.getId());
            if (existing != null) {
                record.setUpdatedAt(now);
                records.set(records.indexOf(existing), record);
            } else {
                record.setCreatedAt(now);
                record.setUpdatedAt(now);
                records.add(record);
            }
        } else {
            int maxId = records.stream().mapToInt(Record::getId).max().orElse(0);
            record.setCreatedAt(now);
            record.setUpdatedAt(now);
            record.setId(maxId);
            records.add(record);
        }
        return record;
    }

    public T find(Integer id) {
        return records.stream().filter(r -> r.getId().equals(id))
                .findFirst().orElse(null);
    }

    public List<T> findByCreatedAtAfter(ZonedDateTime time) {
        return records.stream().filter(r -> !r.getCreatedAt().isBefore(time)).toList();
    }
}
