import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

abstract class Record<ID> {
    private ID id;
    private ZonedDateTime createdAt;
    private ZonedDateTime updatedAt;

    public Record(ID id) {
        this.id = id;
        this.createdAt = ZonedDateTime.now();
        this.updatedAt = ZonedDateTime.now();
    }

    public ID getId() {
        return id;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public ZonedDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setId(ID id) {
        this.id = id;
    }

    public void setUpdatedAt() {
        this.updatedAt = ZonedDateTime.now();
    }
}

class Student extends Record<Integer> {
    private String name;
    private LocalDate dob;

    public Student(Integer id, String name, LocalDate dob) {
        super(id);
        this.name = name;
        this.dob = dob;
    }

    public String getName() {
        return name;
    }

    public LocalDate getDob() {
        return dob;
    }

    // ... Getter và setter cho các trường khác
}

class School extends Record<Integer> {
    private String name;
    private String address;

    public School(Integer id, String name, String address) {
        super(id);
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    // ... Getter và setter cho các trường khác
}

class Database<T extends Record<ID>, ID> {
    private List<T> records = new ArrayList<>();

    public void save(T record) {
        if (record.getId() == null) {
            Integer maxId = records.stream()
                    .mapToInt(r -> (Integer) r.getId())
                    .max()
                    .orElse(0);
            record.setId((ID) (Integer.valueOf(maxId + 1)));
        }

        T existingRecord = find(record.getId());
        if (existingRecord != null) {
            records.remove(existingRecord);
        }

        record.setUpdatedAt();
        records.add(record);
    }

    public T find(ID id) {
        return records.stream()
                .filter(record -> record.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public T delete(ID id) {
        T record = find(id);
        if (record != null) {
            records.remove(record);
            return record;
        }
        return null;
    }

    public List<T> findByCreatedAtAfter(ZonedDateTime time) {
        return records.stream()
                .filter(record -> record.getCreatedAt().compareTo(time) >= 0)
                .toList();
    }

    public List<T> findByUpdatedAtAfter(ZonedDateTime time) {
        return records.stream()
                .filter(record -> record.getUpdatedAt().compareTo(time) >= 0)
                .toList();
    }

    public List<T> getAllRecords() {
        return new ArrayList<>(records);
    }
}

public class Main {
    public static void main(String[] args) {
        Database<Student, Integer> studentDatabase = new Database<>();
        Database<School, Integer> schoolDatabase = new Database<>();

        // Lưu 3 bản ghi Student
        LocalDate dobStudent1 = LocalDate.of(2000, 5, 15);
        Student student1 = new Student(null, "Alice", dobStudent1);
        studentDatabase.save(student1);

        LocalDate dobStudent2 = LocalDate.of(1998, 8, 20);
        Student student2 = new Student(null, "Bob", dobStudent2);
        studentDatabase.save(student2);

        LocalDate dobStudent3 = LocalDate.of(2002, 3, 10);
        Student student3 = new Student(null, "Charlie", dobStudent3);
        studentDatabase.save(student3);

        // Lưu 4 bản ghi School
        School school1 = new School(null, "XYZ School", "456 Elm St");
        schoolDatabase.save(school1);

        School school2 = new School(null, "DEF School", "789 Oak St");
        schoolDatabase.save(school2);

        School school3 = new School(null, "GHI School", "123 Maple St");
        schoolDatabase.save(school3);

        School school4 = new School(null, "JKL School", "567 Pine St");
        schoolDatabase.save(school4);

        // Hiển thị thông tin về các bản ghi đã lưu
        System.out.println("Student records:");
        for (Student student : studentDatabase.getAllRecords()) {
            System.out.println("ID: " + student.getId() + ", Name: " + student.getName() + ", DoB: " + student.getDob() +
                    ", Created At: " + student.getCreatedAt() + ", Updated At: " + student.getUpdatedAt());
        }

        System.out.println("School records:");
        for (School school : schoolDatabase.getAllRecords()) {
            System.out.println("ID: " + school.getId() + ", Name: " + school.getName() + ", Address: " + school.getAddress() +
                    ", Created At: " + school.getCreatedAt() + ", Updated At: " + school.getUpdatedAt());
        }
    }
}


